import pygame
import time
import random
from config import (GRID_SIZE, COLOR_SNAKE_HEAD, COLOR_SNAKE_BODY,
                    COLOR_NORMAL_FOOD, COLOR_SUPER_FOOD, COLOR_POISON_FOOD, COLOR_BLINK_OFF)

class Food:
    """ Base food model abstraction demonstrating polymorphic entity configurations. """
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color

    def get_position(self):
        return (self.x, self.y)

    def draw(self, surface):
        rect = pygame.Rect(self.x * GRID_SIZE, self.y * GRID_SIZE, GRID_SIZE, GRID_SIZE)
        pygame.draw.rect(surface, self.color, rect, border_radius=4)

    def update(self):
        return True  # Persistent entities remain alive automatically


class TimedFood(Food):
    """ Subclass featuring runtime life cycle limits and end-stage frequency blinking. """
    def __init__(self, x, y, color, duration=5.0, blink_start=3.0):
        super().__init__(x, y, color)
        self.creation_time = time.time()
        self.duration = duration
        self.blink_start = blink_start
        self.base_color = color

    def update(self):
        elapsed = time.time() - self.creation_time
        if elapsed >= self.duration:
            return False  # Mark entity for immediate cleanup collection
        
        if elapsed >= self.blink_start:
            # Alternate blinking states at uniform intervals (200ms)
            blink_phase = int((elapsed - self.blink_start) * 5) % 2
            self.color = COLOR_BLINK_OFF if blink_phase == 0 else self.base_color
        return True


class NormalFood(Food):
    def __init__(self, x, y):
        super().__init__(x, y, COLOR_NORMAL_FOOD)


class SuperFood(TimedFood):
    def __init__(self, x, y):
        super().__init__(x, y, COLOR_SUPER_FOOD)


class PoisonFood(TimedFood):
    def __init__(self, x, y):
        super().__init__(x, y, COLOR_POISON_FOOD)


class Snake:
    """ Tracks array dimensions, collision vectors, and kinematic structural expansions. """
    def __init__(self, start_x, start_y):
        self.body = [(start_x, start_y), (start_x - 1, start_y), (start_x - 2, start_y)]
        self.direction = (1, 0)
        self.next_direction = (1, 0)

    def change_direction(self, vector):
        if (vector[0] * -1, vector[1] * -1) != self.direction:
            self.next_direction = vector

    def move(self, grow=False, shrink=False):
        self.direction = self.next_direction
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)
        
        self.body.insert(0, new_head)
        
        if shrink:
            if len(self.body) > 1: self.body.pop()
            if len(self.body) > 1: self.body.pop()  # Pop twice to cancel growth and lose 1 size total
        elif not grow:
            self.body.pop()

    def check_collision(self, bounds_w, bounds_h):
        head = self.body[0]
        if head[0] < 0 or head[0] >= bounds_w or head[1] < 0 or head[1] >= bounds_h:
            return True
        if head in self.body[1:]:
            return True
        return False

    def draw(self, surface):
        for idx, segment in enumerate(self.body):
            color = COLOR_SNAKE_HEAD if idx == 0 else COLOR_SNAKE_BODY
            rect = pygame.Rect(segment[0] * GRID_SIZE, segment[1] * GRID_SIZE, GRID_SIZE, GRID_SIZE)
            pygame.draw.rect(surface, color, rect, border_radius=3)
            pygame.draw.rect(surface, (16, 40, 20), rect, 1)\n