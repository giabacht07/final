import json
import os
import time
from decorators import history_pipeline

class GameHistoryManager:
    """ Manages structural history logging, sorting data streams from lowest to highest score. """
    def __init__(self, filename="snake_history.json"):
        self.filename = filename

    def load_history(self):
        if not os.path.exists(self.filename):
            return []
        try:
            with open(self.filename, "r") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except (json.JSONDecodeError, IOError):
            return []

    @history_pipeline
    def save_record(self, name, score):
        history = self.load_history()
        history.append({
            "name": name,
            "score": score,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        })
        
        # Sort sequentially from lowest score to highest score
        history.sort(key=lambda item: item["score"])
        
        try:
            with open(self.filename, "w") as f:
                json.dump(history, f, indent=4)
        except IOError as e:
            print(f"[IO EXCEPTION] Failed flushing database pipeline: {e}")\n