import pygame
import time
import random
import sys

from config import (WIDTH, HEIGHT, GRID_SIZE, GRID_WIDTH, GRID_HEIGHT, TOTAL_TILES, FPS,
                    COLOR_BG, COLOR_GRID, COLOR_TEXT, COLOR_TEXT_MUTED)
from decorators import log_game_event
from history import GameHistoryManager
from entities import Snake, NormalFood, SuperFood, PoisonFood
from ui import Button, TextInput

class GameApp:
    """ Primary application kernel managing GUI scene routing and layout composition. """
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Scalable OOP Architecture - Snake Ecosystem")
        self.clock = pygame.time.Clock()
        
        self.font_title = pygame.font.SysFont("Arial", 46, bold=True)
        self.font_ui = pygame.font.SysFont("Arial", 22, bold=True)
        self.font_sm = pygame.font.SysFont("Arial", 16)

        self.history_manager = GameHistoryManager()
        self.state = "MENU"
        
        self.setup_menu_ui()
        self.reset_game_state()

    def setup_menu_ui(self):
        mid_x = WIDTH // 2
        self.name_input = TextInput(mid_x - 125, 170, 250, 45, self.font_ui)
        
        self.menu_buttons = [
            Button(mid_x - 125, 240, 250, 45, "Start Simulation", self.font_ui, self.start_game),
            Button(mid_x - 125, 300, 250, 45, "View Leaderboard", self.font_ui, self.open_leaderboard),
            Button(mid_x - 125, 360, 250, 45, "Exit Application", self.font_ui, self.terminate_app)
        ]
        
        self.leaderboard_buttons = [
            Button(mid_x - 125, HEIGHT - 80, 250, 45, "Return to Menu", self.font_ui, self.open_menu)
        ]

    def reset_game_state(self):
        self.snake = Snake(GRID_WIDTH // 2, GRID_HEIGHT // 2)
        self.normal_food = None
        self.special_foods = []
        self.spawn_normal_food()
        self.last_special_spawn = time.time()
        self.game_over = False
        self.game_won = False

    def get_vacant_cells(self):
        occupied = set(self.snake.body)
        if self.normal_food:
            occupied.add(self.normal_food.get_position())
        for sf in self.special_foods:
            occupied.add(sf.get_position())
        return [(x, y) for x in range(GRID_WIDTH) for y in range(GRID_HEIGHT) if (x, y) not in occupied]

    def spawn_normal_food(self):
        vacant = self.get_vacant_cells()
        if vacant:
            pos = random.choice(vacant)
            self.normal_food = NormalFood(pos[0], pos[1])

    @log_game_event
    def trigger_special_spawn(self):
        vacant = self.get_vacant_cells()
        if len(vacant) < 2: return "Rejected: Map full"
        
        choice = random.choice(["SUPER", "POISON", "BOTH"])
        if choice in ["SUPER", "BOTH"]:
            pos = random.choice(vacant)
            self.special_foods.append(SuperFood(pos[0], pos[1]))
            vacant.remove(pos)
        if choice in ["POISON", "BOTH"] and vacant:
            pos = random.choice(vacant)
            self.special_foods.append(PoisonFood(pos[0], pos[1]))
        return f"Dispatched entities matrix: {choice}"

    def start_game(self):
        self.reset_game_state()
        self.state = "GAME"

    def open_leaderboard(self):
        self.state = "LEADERBOARD"

    def open_menu(self):
        self.state = "MENU"

    def terminate_app(self):
        pygame.quit()
        sys.exit()

    def execute(self):
        while True:
            self.process_events()
            self.update_states()
            self.render_graphics()
            self.clock.tick(FPS)

    def process_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.terminate_app()
                
            if self.state == "MENU":
                self.name_input.handle_event(event)
                for btn in self.menu_buttons: btn.handle_event(event)
            elif self.state == "LEADERBOARD":
                for btn in self.leaderboard_buttons: btn.handle_event(event)
            elif self.state == "GAME":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:     self.snake.change_direction((0, -1))
                    elif event.key == pygame.K_DOWN:   self.snake.change_direction((0, 1))
                    elif event.key == pygame.K_LEFT:   self.snake.change_direction((-1, 0))
                    elif event.key == pygame.K_RIGHT:  self.snake.change_direction((1, 0))
                    elif event.key == pygame.K_ESCAPE: self.state = "MENU"
                    elif event.key == pygame.K_r and (self.game_over or self.game_won):
                        self.reset_game_state()

    def update_states(self):
        if self.state != "GAME" or self.game_over or self.game_won:
            return

        self.special_foods = [sf for sf in self.special_foods if sf.update()]

        if time.time() - self.last_special_spawn >= 8.0:
            self.trigger_special_spawn()
            self.last_special_spawn = time.time()

        grow, shrink = False, False
        head_x, head_y = self.snake.body[0]
        dx, dy = self.snake.next_direction
        next_head_pos = (head_x + dx, head_y + dy)

        if next_head_pos == self.normal_food.get_position():
            grow = True
            self.spawn_normal_food()
        else:
            eaten_item = next((sf for sf in self.special_foods if next_head_pos == sf.get_position()), None)
            if eaten_item:
                self.special_foods.remove(eaten_item)
                if isinstance(eaten_item, SuperFood):
                    grow = True
                    for _ in range(2): self.snake.body.append(self.snake.body[-1])
                elif isinstance(eaten_item, PoisonFood):
                    shrink = True

        self.snake.move(grow=grow, shrink=shrink)

        if len(self.snake.body) == 0 or self.snake.check_collision(GRID_WIDTH, GRID_HEIGHT):
            self.game_over = True
            self.history_manager.save_record(self.name_input.text, len(self.snake.body))
            return

        if len(self.snake.body) >= TOTAL_TILES:
            self.game_won = True
            self.history_manager.save_record(self.name_input.text, len(self.snake.body))

    def render_graphics(self):
        self.screen.fill(COLOR_BG)

        if self.state == "MENU":
            title = self.font_title.render("SNAKE ECOSYSTEM", True, COLOR_TEXT)
            self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 60))
            lbl = self.font_sm.render("Enter Profile Name Configuration:", True, COLOR_TEXT_MUTED)
            self.screen.blit(lbl, (WIDTH // 2 - 125, 145))
            self.name_input.draw(self.screen)
            for btn in self.menu_buttons: btn.draw(self.screen)

        elif self.state == "LEADERBOARD":
            title = self.font_title.render("SCOREBOARD HISTORY", True, COLOR_TEXT)
            self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))
            
            records = self.history_manager.load_history()
            start_y = 130
            header = self.font_ui.render(f"{'Index':<10}{'Player Name':<22}{'Length Achieved'}", True, COLOR_TEXT_MUTED)
            self.screen.blit(header, (80, start_y))
            pygame.draw.line(self.screen, (60, 65, 70), (80, start_y + 30), (WIDTH - 80, start_y + 30), 2)
            
            start_y += 45
            for idx, item in enumerate(records[:7], 1):
                row_str = f"#{idx:<9}{item['name']:<25}{item['score']} segments"
                self.screen.blit(self.font_sm.render(row_str, True, COLOR_TEXT), (80, start_y))
                start_y += 30
                
            if not records:
                empty_surf = self.font_ui.render("No pipeline files initialized.", True, COLOR_TEXT_MUTED)
                self.screen.blit(empty_surf, (WIDTH // 2 - empty_surf.get_width() // 2, HEIGHT // 2 - 20))
                
            for btn in self.leaderboard_buttons: btn.draw(self.screen)

        elif self.state == "GAME":
            for x in range(GRID_WIDTH):
                pygame.draw.line(self.screen, COLOR_GRID, (x * GRID_SIZE, 0), (x * GRID_SIZE, HEIGHT))
            for y in range(GRID_HEIGHT):
                pygame.draw.line(self.screen, COLOR_GRID, (0, y * GRID_SIZE), (WIDTH, y * GRID_SIZE))

            if self.normal_food: self.normal_food.draw(self.screen)
            for sf in self.special_foods: sf.draw(self.screen)
            self.snake.draw(self.screen)

            hud_str = f"User Context: {self.name_input.text}  |  Length: {len(self.snake.body)} / {TOTAL_TILES}"
            self.screen.blit(self.font_sm.render(hud_str, True, COLOR_TEXT), (15, 12))

            if self.game_over: self.draw_overlay("CRITICAL COLLISION: GAME OVER", (231, 76, 60))
            elif self.game_won: self.draw_overlay("ECOSYSTEM COMPLETED: VICTORY!", (46, 204, 113))

        pygame.display.flip()

    def draw_overlay(self, message, txt_color):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((15, 15, 15, 200))
        self.screen.blit(overlay, (0, 0))
        self.screen.blit(self.font_title.render(message, True, txt_color), (WIDTH // 2 - 250, HEIGHT // 2 - 40))
        self.screen.blit(self.font_ui.render("Press 'R' to Respawn or ESC to return to Menu", True, COLOR_TEXT), (WIDTH // 2 - 220, HEIGHT // 2 + 20))

if __name__ == "__main__":
    app = GameApp()
    app.execute()\n