import pygame
from config import COLOR_BUTTON, COLOR_BUTTON_HOVER, COLOR_TEXT, COLOR_TEXT_MUTED

class Button:
    """ Fully interactive UI event button module tracking coordinate collision. """
    def __init__(self, x, y, width, height, text, font, callback):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.callback = callback

    def draw(self, surface):
        mouse_pos = pygame.mouse.get_pos()
        color = COLOR_BUTTON_HOVER if self.rect.collidepoint(mouse_pos) else COLOR_BUTTON
        
        pygame.draw.rect(surface, color, self.rect, border_radius=6)
        pygame.draw.rect(surface, (100, 110, 120), self.rect, 2, border_radius=6)
        
        text_surf = self.font.render(self.text, True, COLOR_TEXT)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.callback()


class TextInput:
    """ Canvas context graphical text widget tracking user keystroke events. """
    def __init__(self, x, y, width, height, font, default_text="Player1"):
        self.rect = pygame.Rect(x, y, width, height)
        self.font = font
        self.text = default_text
        self.active = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                if len(self.text) < 12 and (event.unicode.isalnum() or event.unicode in " _-"):
                    self.text += event.unicode

    def draw(self, surface):
        bg_color = (40, 45, 48) if self.active else (30, 33, 35)
        border_color = (52, 152, 219) if self.active else (70, 75, 80)
        
        pygame.draw.rect(surface, bg_color, self.rect, border_radius=6)
        pygame.draw.rect(surface, border_color, self.rect, 2, border_radius=6)
        
        display_text = self.text if self.text else "Type Profile..."
        text_color = COLOR_TEXT if self.text else COLOR_TEXT_MUTED
        
        text_surf = self.font.render(display_text, True, text_color)
        text_rect = text_surf.get_rect(midleft=(self.rect.x + 12, self.rect.centery))
        surface.blit(text_surf, text_rect)\n